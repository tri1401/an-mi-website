import { useState, useCallback } from 'react';
import { CartProvider } from '@/context/CartContext';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import ProductCatalog from '@/components/ProductCatalog';
import NutritionTable from '@/components/NutritionTable';
import StorySection from '@/components/StorySection';
import PricingSection from '@/components/PricingSection';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import CheckoutModal from '@/components/CheckoutModal';

function App() {
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  const openCheckout = useCallback(() => setCheckoutOpen(true), []);
  const closeCheckout = useCallback(() => setCheckoutOpen(false), []);

  return (
    <CartProvider>
      <div className="min-h-screen bg-white">
        <Header />
        <main>
          <Hero />
          <ProductCatalog />
          <NutritionTable />
          <StorySection />
          <PricingSection />
        </main>
        <Footer />
        <CartDrawer onCheckout={openCheckout} />
        <CheckoutModal isOpen={checkoutOpen} onClose={closeCheckout} />
      </div>
    </CartProvider>
  );
}

export default App;
