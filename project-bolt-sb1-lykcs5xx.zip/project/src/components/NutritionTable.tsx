import { Check, X, AlertCircle } from 'lucide-react';
import { nutritionRows } from '@/data/products';

type CellType = 'good' | 'bad' | 'neutral';

function getCellType(rowLabel: string, value: string, column: 'anMi' | 'traditional' | 'shirataki'): CellType {
  if (column === 'anMi') return 'good';
  const lower = value.toLowerCase();
  if (lower.includes('chiên') || lower.includes('trans-fat') || lower.includes('có')) return 'bad';
  if (lower.includes('0') || lower.includes('0g') || lower.includes('0%')) return 'good';
  return 'neutral';
}

export default function NutritionTable() {
  return (
    <section id="nutrition" className="py-20 lg:py-28 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 max-w-2xl mx-auto">
          <span className="inline-block px-4 py-1.5 bg-primary-100 text-primary-700 text-sm font-semibold rounded-full mb-4">
            Dinh dưỡng
          </span>
          <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-gray-900 mb-4">
            So Sánh Dinh Dưỡng
          </h2>
          <p className="text-gray-600 leading-[150%]">
            AN MÌ so với mì chiên truyền thống và mì nhập khẩu Shirataki – sự khác biệt rõ ràng về sức khỏe.
          </p>
        </div>

        {/* Desktop table */}
        <div className="hidden md:block overflow-hidden rounded-2xl border border-gray-200 shadow-lg shadow-primary-900/5">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50">
                <th className="text-left px-6 py-4 font-semibold text-gray-700 text-sm">Tiêu chí</th>
                <th className="px-6 py-4 font-display font-bold text-primary-700 text-sm bg-primary-50/50">
                  AN MÌ
                </th>
                <th className="px-6 py-4 font-semibold text-gray-500 text-sm">Mì chiên truyền thống</th>
                <th className="px-6 py-4 font-semibold text-gray-500 text-sm">Mì Eat Clean Khác (Shirataki/Konjac)</th>
              </tr>
            </thead>
            <tbody>
              {nutritionRows.map((row, idx) => (
                <tr
                  key={row.label}
                  className={`border-t border-gray-100 ${row.highlight ? 'bg-primary-50/30' : ''} ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'}`}
                >
                  <td className="px-6 py-4 text-sm font-medium text-gray-700">{row.label}</td>
                  <td className="px-6 py-4 text-center bg-primary-50/40">
                    <div className="inline-flex items-center gap-1.5 font-bold text-primary-700 text-sm">
                      <Check className="w-4 h-4 text-primary-600" />
                      {row.anMi}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className={`inline-flex items-center gap-1.5 text-sm ${
                      getCellType(row.label, row.traditional, 'traditional') === 'bad' ? 'text-red-500 font-semibold' : 'text-gray-600'
                    }`}>
                      {getCellType(row.label, row.traditional, 'traditional') === 'bad' && <X className="w-4 h-4" />}
                      {row.traditional}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className={`inline-flex items-center gap-1.5 text-sm ${
                      getCellType(row.label, row.shirataki, 'shirataki') === 'bad' ? 'text-accent-600 font-semibold' : 'text-gray-600'
                    }`}>
                      {getCellType(row.label, row.shirataki, 'shirataki') === 'bad' && <AlertCircle className="w-4 h-4" />}
                      {row.shirataki}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="md:hidden space-y-4">
          {nutritionRows.map(row => (
            <div key={row.label} className={`rounded-xl border p-4 ${row.highlight ? 'border-primary-200 bg-primary-50/30' : 'border-gray-100 bg-gray-50/30'}`}>
              <h3 className="font-semibold text-gray-700 text-sm mb-3">{row.label}</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-primary-700">AN MÌ</span>
                  <span className="text-sm font-bold text-primary-700 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    {row.anMi}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">Mì truyền thống</span>
                  <span className={`text-sm ${getCellType(row.label, row.traditional, 'traditional') === 'bad' ? 'text-red-500 font-semibold' : 'text-gray-600'}`}>
                    {row.traditional}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">Mì Eat Clean Khác (Shirataki/Konjac)</span>
                  <span className={`text-sm ${getCellType(row.label, row.shirataki, 'shirataki') === 'bad' ? 'text-accent-600 font-semibold' : 'text-gray-600'}`}>
                    {row.shirataki}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
