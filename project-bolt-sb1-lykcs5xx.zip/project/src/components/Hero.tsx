import { ArrowRight, BookOpen, Snowflake, Leaf, Heart } from 'lucide-react';
import anMiProductImage from '@/assets/an-mi-product.svg';

export default function Hero() {
  return (
    <section id="hero" className="relative pt-20 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary-50 via-cream to-white" />
      <div className="absolute top-20 right-0 w-96 h-96 bg-primary-200/30 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent-100/40 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="flex flex-col gap-6 animate-slide-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-primary-200 rounded-full shadow-sm w-fit">
              <Leaf className="w-4 h-4 text-primary-600" />
              <span className="text-sm font-semibold text-primary-700">Nông sản OCOP Bình Mỹ – Eat Clean</span>
            </div>

            <h1 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl text-primary-900 leading-[120%]">
              Mì Xơ Mít Sấy Lạnh Eat Clean –{' '}
              <span className="text-accent-500">Giải Pháp Xanh</span> Từ Bình Mỹ
            </h1>

            <p className="text-base lg:text-lg text-gray-600 leading-[150%] max-w-xl">
              Bổ sung 15-20% chất xơ tự nhiên, giảm 35% tinh bột, 0% Trans-fat, sấy lạnh -35°C không qua chiên dầu.
            </p>

            <div className="flex flex-wrap gap-3">
              <a
                href="#products"
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-primary-700 text-white font-semibold rounded-xl shadow-lg shadow-primary-700/30 hover:bg-primary-800 hover:scale-105 active:scale-95 transition-all"
              >
                Đặt Hàng Ngay
                <ArrowRight className="w-5 h-5" />
              </a>
              <a
                href="#story"
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-white text-primary-700 font-semibold rounded-xl border-2 border-primary-200 hover:border-primary-400 hover:bg-primary-50 transition-all"
              >
                <BookOpen className="w-5 h-5" />
                Khám Phá Câu Chuyện
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6">
              {[
                { value: '15-20%', label: 'Chất xơ tự nhiên' },
                { value: '-35°C', label: 'Sấy lạnh không chiên' },
                { value: '0%', label: 'Trans-fat' },
              ].map(stat => (
                <div key={stat.label} className="text-center sm:text-left">
                  <div className="text-2xl lg:text-3xl font-display font-extrabold text-primary-700">{stat.value}</div>
                  <div className="text-xs lg:text-sm text-gray-500 mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right image */}
          <div className="relative animate-fade-in">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-primary-900/20 aspect-[4/3]">
              <img
                src={anMiProductImage}
                alt="Mì xơ mít sấy lạnh AN MÌ"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary-900/40 to-transparent" />
            </div>

            {/* Floating badges */}
            <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-xl p-4 flex items-center gap-3 animate-bounce-subtle">
              <div className="w-10 h-10 rounded-xl bg-accent-50 flex items-center justify-center">
                <Snowflake className="w-5 h-5 text-accent-500" />
              </div>
              <div>
                <div className="text-sm font-bold text-gray-900">Freeze-drying</div>
                <div className="text-xs text-gray-500">-35°C không chiên dầu</div>
              </div>
            </div>

            <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center">
                <Heart className="w-5 h-5 text-primary-600" />
              </div>
              <div>
                <div className="text-sm font-bold text-gray-900">Eat Clean</div>
                <div className="text-xs text-gray-500">Giảm 35% tinh bột</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
