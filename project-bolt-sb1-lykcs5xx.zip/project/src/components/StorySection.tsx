import { Sprout, Blend, Waves, Snowflake, Package, Award, Leaf, Heart } from 'lucide-react';
import { processSteps } from '@/data/products';
import anMiProductImage from '@/assets/an-mi-product.svg';

const iconMap: Record<string, typeof Sprout> = {
  sprout: Sprout,
  blend: Blend,
  waves: Waves,
  snowflake: Snowflake,
  package: Package,
};

export default function StorySection() {
  return (
    <section id="story" className="py-20 lg:py-28 bg-gradient-to-b from-cream to-primary-50/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Story intro */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="relative">
            <div className="rounded-3xl overflow-hidden shadow-2xl shadow-primary-900/20 aspect-[4/3]">
              <img
                src={anMiProductImage}
                alt="Nông sản OCOP Bình Mỹ"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-5 -right-5 bg-white rounded-2xl shadow-xl p-5 flex items-center gap-3 max-w-[200px]">
              <div className="w-12 h-12 rounded-xl bg-accent-50 flex items-center justify-center flex-shrink-0">
                <Award className="w-6 h-6 text-accent-500" />
              </div>
              <div>
                <div className="text-sm font-bold text-gray-900">OCOP 3 Sao</div>
                <div className="text-xs text-gray-500">Bình Mỹ – Củ Chi</div>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-5">
            <span className="inline-block px-4 py-1.5 bg-primary-100 text-primary-700 text-sm font-semibold rounded-full w-fit">
              Câu chuyện
            </span>
            <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-gray-900 leading-[120%]">
              Từ Xơ Mít Bình Mỹ Đến Giải Pháp Eat Clean
            </h2>
            <p className="text-gray-600 leading-[150%]">
              AN MÌ là dự án khởi nghiệp sinh viên HUTECH, kết hợp nông sản đặc trưng của Bình Mỹ – xơ mít – với công nghệ sấy lạnh freeze-drying hiện đại. Mỗi gói mì là câu chuyện về nông sản Việt, phát triển bền vững và sức khỏe cộng đồng.
            </p>
            <div className="grid grid-cols-3 gap-4 pt-2">
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center mb-2">
                  <Leaf className="w-6 h-6 text-primary-600" />
                </div>
                <span className="text-xs font-semibold text-gray-700">Nông sản Việt</span>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center mb-2">
                  <Snowflake className="w-6 h-6 text-primary-600" />
                </div>
                <span className="text-xs font-semibold text-gray-700">Sấy lạnh -35°C</span>
              </div>
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-xl bg-primary-50 flex items-center justify-center mb-2">
                  <Heart className="w-6 h-6 text-primary-600" />
                </div>
                <span className="text-xs font-semibold text-gray-700">Eat Clean</span>
              </div>
            </div>
          </div>
        </div>

        {/* Process steps */}
        <div className="text-center mb-12">
          <h3 className="font-display font-extrabold text-2xl lg:text-3xl text-gray-900 mb-3">
            5 Bước Sản Xuất AN MÌ
          </h3>
          <p className="text-gray-600">Quy trình khép kín từ nguyên liệu đến đóng gói OCOP</p>
        </div>

        <div className="relative">
          {/* Connecting line */}
          <div className="hidden lg:block absolute top-16 left-[10%] right-[10%] h-0.5 bg-gradient-to-r from-primary-200 via-primary-300 to-primary-200" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-4">
            {processSteps.map((step, idx) => {
              const Icon = iconMap[step.icon] || Sprout;
              return (
                <div
                  key={step.step}
                  className="relative flex flex-col items-center text-center group animate-slide-up"
                  style={{ animationDelay: `${idx * 100}ms` }}
                >
                  <div className="relative w-16 h-16 rounded-2xl bg-white border-2 border-primary-100 flex items-center justify-center shadow-md group-hover:shadow-lg group-hover:border-primary-400 group-hover:scale-105 transition-all z-10">
                    <Icon className="w-7 h-7 text-primary-600" />
                    <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-accent-500 text-white text-xs font-bold flex items-center justify-center shadow-md">
                      {step.step}
                    </span>
                  </div>
                  <h4 className="font-display font-bold text-sm text-gray-900 mt-4 mb-2 leading-snug">
                    {step.title}
                  </h4>
                  <p className="text-xs text-gray-500 leading-[150%]">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
