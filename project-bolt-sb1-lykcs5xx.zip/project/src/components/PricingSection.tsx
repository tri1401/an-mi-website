import { ShoppingBag, ArrowRight, Check } from 'lucide-react';
import { products } from '@/data/products';
import { formatVND } from '@/context/CartContext';

export default function PricingSection() {
  return (
    <section id="pricing" className="py-20 lg:py-28 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 max-w-2xl mx-auto">
          <span className="inline-block px-4 py-1.5 bg-primary-100 text-primary-700 text-sm font-semibold rounded-full mb-4">
            Bảng giá
          </span>
          <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-gray-900 mb-4">
            Bảng Giá AN MÌ
          </h2>
          <p className="text-gray-600 leading-[150%]">
            Mua lẻ tiết kiệm, mua thùng giảm thêm. Miễn phí vận chuyển cho đơn hàng trên 100.000đ.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          {/* Retail card */}
          <div className="rounded-2xl border-2 border-gray-200 p-8 hover:border-primary-300 hover:shadow-lg transition-all">
            <h3 className="font-display font-bold text-xl text-gray-900 mb-2">Mua Lẻ</h3>
            <p className="text-sm text-gray-500 mb-6">Phù hợp cho dùng thử và tiêu dùng cá nhân</p>
            <div className="space-y-3 mb-6">
              {products.filter(p => !p.isBundle).map(p => (
                <div key={p.id} className="flex items-center justify-between pb-3 border-b border-gray-100 last:border-0">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-primary-600" />
                    <span className="text-sm text-gray-700">{p.shortName}</span>
                  </div>
                  <span className="font-bold text-primary-700 text-sm">{formatVND(p.price)}</span>
                </div>
              ))}
            </div>
            <a
              href="#products"
              className="inline-flex items-center gap-2 px-5 py-3 bg-primary-50 text-primary-700 font-semibold rounded-xl hover:bg-primary-100 transition-colors text-sm w-full justify-center"
            >
              <ShoppingBag className="w-4 h-4" />
              Mua ngay
            </a>
          </div>

          {/* Bundle card */}
          <div className="relative rounded-2xl border-2 border-primary-500 p-8 bg-primary-50/30 hover:shadow-xl transition-all overflow-hidden">
            <div className="absolute top-0 right-0 px-3 py-1 bg-accent-500 text-white text-xs font-bold rounded-bl-xl">
              Tiết kiệm hơn
            </div>
            <h3 className="font-display font-bold text-xl text-gray-900 mb-2">Mua Thùng</h3>
            <p className="text-sm text-gray-500 mb-6">Tối ưu cho gia đình, căng tin & văn phòng</p>
            <div className="space-y-3 mb-6">
              {products.filter(p => p.isBundle).map(p => (
                <div key={p.id} className="flex items-center justify-between pb-3 border-b border-primary-100 last:border-0">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-primary-600" />
                    <span className="text-sm text-gray-700">{p.shortName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400 line-through">{formatVND(p.originalPrice!)}</span>
                    <span className="font-bold text-primary-700 text-sm">{formatVND(p.price)}</span>
                  </div>
                </div>
              ))}
            </div>
            <a
              href="#products"
              className="inline-flex items-center gap-2 px-5 py-3 bg-primary-700 text-white font-semibold rounded-xl hover:bg-primary-800 hover:shadow-lg transition-all text-sm w-full justify-center"
            >
              Mua thùng tiết kiệm
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Shipping note */}
        <div className="mt-8 flex items-center justify-center gap-2 text-sm text-gray-500">
          <Check className="w-4 h-4 text-primary-600" />
          Miễn phí vận chuyển cho đơn hàng từ 100.000đ
        </div>
      </div>
    </section>
  );
}
