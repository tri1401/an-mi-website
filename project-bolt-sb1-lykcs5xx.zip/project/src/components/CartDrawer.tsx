import { useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, Truck } from 'lucide-react';
import { useCart, formatVND } from '@/context/CartContext';

interface CartDrawerProps {
  onCheckout: () => void;
}

export default function CartDrawer({ onCheckout }: CartDrawerProps) {
  const { items, isCartOpen, closeCart, updateQuantity, removeFromCart, subtotal, shippingFee, total, totalItems } = useCart();

  return (
    <>
      {/* Overlay */}
      {isCartOpen && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 animate-fade-in"
          onClick={closeCart}
        />
      )}

      {/* Drawer */}
      <div
        className={`fixed top-0 right-0 bottom-0 w-full sm:w-[420px] bg-white z-50 shadow-2xl flex flex-col transition-transform duration-300 ${
          isCartOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-primary-700" />
            <h3 className="font-display font-bold text-lg text-gray-900">
              Giỏ hàng {totalItems > 0 && `(${totalItems})`}
            </h3>
          </div>
          <button
            onClick={closeCart}
            className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            aria-label="Đóng"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-3">
              <div className="w-20 h-20 rounded-full bg-gray-50 flex items-center justify-center">
                <ShoppingBag className="w-10 h-10 text-gray-300" />
              </div>
              <p className="text-gray-400 font-medium">Giỏ hàng của bạn đang trống</p>
              <button
                onClick={closeCart}
                className="px-5 py-2.5 bg-primary-700 text-white font-semibold rounded-xl hover:bg-primary-800 transition-colors text-sm"
              >
                Tiếp tục mua sắm
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {items.map(item => (
                <div
                  key={item.product.id}
                  className="flex gap-3 p-3 bg-gray-50 rounded-xl animate-scale-in"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-semibold text-sm text-gray-900 leading-snug">{item.product.shortName}</h4>
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
                        aria-label="Xóa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-sm text-primary-700 font-bold mt-1">{formatVND(item.product.price)}</p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="p-1 hover:bg-gray-100 transition-colors"
                        >
                          <Minus className="w-3.5 h-3.5 text-gray-600" />
                        </button>
                        <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          className="p-1 hover:bg-gray-100 transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5 text-gray-600" />
                        </button>
                      </div>
                      <span className="font-bold text-sm text-gray-900">
                        {formatVND(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-gray-100 px-5 py-4 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Tạm tính</span>
              <span className="font-semibold text-gray-900">{formatVND(subtotal)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600 flex items-center gap-1">
                <Truck className="w-4 h-4" /> Phí vận chuyển
              </span>
              <span className="font-semibold text-gray-900">
                {shippingFee === 0 ? <span className="text-primary-600">Miễn phí</span> : formatVND(shippingFee)}
              </span>
            </div>
            {shippingFee === 0 && (
              <p className="text-xs text-primary-600 bg-primary-50 rounded-lg px-3 py-2">
                Đơn hàng trên 100.000đ được miễn phí vận chuyển!
              </p>
            )}
            {shippingFee > 0 && subtotal > 0 && (
              <p className="text-xs text-accent-600 bg-accent-50 rounded-lg px-3 py-2">
                Mua thêm {formatVND(100000 - subtotal)} để được miễn phí vận chuyển!
              </p>
            )}
            <div className="flex items-center justify-between pt-2 border-t border-gray-100">
              <span className="font-bold text-gray-900">Tổng cộng</span>
              <span className="font-display font-extrabold text-xl text-primary-700">{formatVND(total)}</span>
            </div>
            <button
              onClick={onCheckout}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-primary-700 text-white font-semibold rounded-xl hover:bg-primary-800 hover:shadow-lg hover:shadow-primary-700/25 active:scale-95 transition-all"
            >
              Tiến hành đặt hàng
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </>
  );
}
