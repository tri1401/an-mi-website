import { Leaf, Phone, Mail, MapPin, Facebook, Award, Heart } from 'lucide-react';

const socialLinks = [
  { label: 'TikTok Shop', href: '#', icon: '🎵' },
  { label: 'Facebook', href: '#', icon: Facebook },
  { label: 'Hotline', href: 'tel:0901234567', icon: Phone },
];

export default function Footer() {
  return (
    <footer className="bg-primary-900 text-white">
      {/* Top section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-10">
          {/* Brand */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary-700 flex items-center justify-center">
                <Leaf className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-display font-extrabold text-lg">AN MÌ</div>
                <div className="text-xs text-primary-300">Mì Xơ Mít Bình Mỹ</div>
              </div>
            </div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary-800 border border-primary-700 rounded-full w-fit">
              <Award className="w-4 h-4 text-accent-400" />
              <span className="text-xs font-semibold text-accent-300">Sản phẩm OCOP 3 Sao Bình Mỹ</span>
            </div>
            <p className="text-sm text-primary-300 leading-[150%]">
              Dự án Khởi nghiệp Sinh viên HUTECH – Nông sản OCOP Bình Mỹ. Giải pháp mì eat clean từ xơ mít, sấy lạnh không chiên dầu.
            </p>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-4">
            <h4 className="font-display font-bold text-base mb-1">Liên hệ</h4>
            <div className="flex items-start gap-3">
              <Phone className="w-5 h-5 text-primary-400 flex-shrink-0 mt-0.5" />
              <div>
                <div className="text-sm text-primary-300">Hotline</div>
                <a href="tel:0901234567" className="text-sm font-semibold text-white hover:text-accent-300 transition-colors">
                  0901 234 567
                </a>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Mail className="w-5 h-5 text-primary-400 flex-shrink-0 mt-0.5" />
              <div>
                <div className="text-sm text-primary-300">Email</div>
                <a href="mailto:anmi.binhmy@gmail.com" className="text-sm font-semibold text-white hover:text-accent-300 transition-colors">
                  anmi.binhmy@gmail.com
                </a>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-primary-400 flex-shrink-0 mt-0.5" />
              <div>
                <div className="text-sm text-primary-300">Địa chỉ</div>
                <span className="text-sm font-semibold text-white">Bình Mỹ, Củ Chi, TP.HCM</span>
              </div>
            </div>
          </div>

          {/* Social & Links */}
          <div className="flex flex-col gap-4">
            <h4 className="font-display font-bold text-base mb-1">Kết nối với chúng tôi</h4>
            <div className="flex flex-col gap-2.5">
              <a
                href="#"
                className="inline-flex items-center gap-3 px-4 py-2.5 bg-primary-800 rounded-xl text-sm font-medium hover:bg-primary-700 transition-colors"
              >
                <span className="text-lg">🎵</span>
                TikTok Shop – @anmi.binhmy
              </a>
              <a
                href="#"
                className="inline-flex items-center gap-3 px-4 py-2.5 bg-primary-800 rounded-xl text-sm font-medium hover:bg-primary-700 transition-colors"
              >
                <Facebook className="w-5 h-5" />
                Facebook – AN MÌ Bình Mỹ
              </a>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {[
                { label: 'Trang chủ', href: '#hero' },
                { label: 'Sản phẩm', href: '#products' },
                { label: 'Dinh dưỡng', href: '#nutrition' },
                { label: 'Câu chuyện', href: '#story' },
              ].map(link => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-sm text-primary-300 hover:text-white transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-primary-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-primary-400">
            © 2026 AN MÌ – Mì Xơ Mít Bình Mỹ. Dự án Khởi nghiệp Sinh viên HUTECH.
          </p>
          <p className="text-xs text-primary-400 flex items-center gap-1.5">
            Made with <Heart className="w-3.5 h-3.5 text-accent-400 fill-accent-400" /> in Bình Mỹ, Củ Chi
          </p>
        </div>
      </div>
    </footer>
  );
}
