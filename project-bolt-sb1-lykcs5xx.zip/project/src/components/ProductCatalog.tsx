import { useState } from 'react';
import { Plus, Minus, ShoppingBag, Check, Package, Tag } from 'lucide-react';
import { products, type Product } from '@/data/products';
import { useCart, formatVND } from '@/context/CartContext';

function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);

  const handleAdd = () => {
    addToCart(product, quantity);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-primary-900/10 transition-all duration-300 flex flex-col">
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden bg-primary-50">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {discount > 0 && (
            <span className="px-2.5 py-1 bg-accent-500 text-white text-xs font-bold rounded-full shadow-md">
              -{discount}%
            </span>
          )}
          {product.isBundle && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-primary-700 text-white text-xs font-semibold rounded-full shadow-md">
              <Package className="w-3 h-3" />
              Quy cách thùng
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex flex-col flex-1">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary-50 text-primary-700 text-xs font-medium rounded-full w-fit">
            <Tag className="w-3 h-3" />
            {product.badge}
          </span>
          <span className="px-2.5 py-1 bg-accent-50 text-accent-700 text-xs font-bold rounded-full border border-accent-100">
            {product.weight}/{product.unit}
          </span>
        </div>

        <h3 className="font-display font-bold text-lg text-gray-900 leading-snug mb-1">
          {product.name}
        </h3>
        <p className="text-sm text-gray-500 mb-4 leading-[150%] flex-1">{product.description}</p>

        {/* Features */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {product.features.map(feat => (
            <span key={feat} className="px-2 py-1 bg-gray-50 text-gray-600 text-xs rounded-md border border-gray-100">
              {feat}
            </span>
          ))}
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-2 mb-4">
          <span className="text-2xl font-display font-extrabold text-primary-700">{formatVND(product.price)}</span>
          {product.originalPrice && (
            <span className="text-sm text-gray-400 line-through">{formatVND(product.originalPrice)}</span>
          )}
          <span className="text-sm text-gray-500">/ {product.unit}</span>
        </div>

        {/* Quantity & Add */}
        <div className="flex items-center gap-3">
          <div className="flex items-center border-2 border-gray-200 rounded-xl overflow-hidden">
            <button
              onClick={() => setQuantity(q => Math.max(1, q - 1))}
              className="p-2 hover:bg-gray-50 transition-colors"
              aria-label="Giảm số lượng"
            >
              <Minus className="w-4 h-4 text-gray-600" />
            </button>
            <span className="w-10 text-center font-semibold text-gray-900 select-none">{quantity}</span>
            <button
              onClick={() => setQuantity(q => Math.min(99, q + 1))}
              className="p-2 hover:bg-gray-50 transition-colors"
              aria-label="Tăng số lượng"
            >
              <Plus className="w-4 h-4 text-gray-600" />
            </button>
          </div>
          <button
            onClick={handleAdd}
            className={`flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-all ${
              justAdded
                ? 'bg-primary-600 text-white scale-95'
                : 'bg-primary-700 text-white hover:bg-primary-800 hover:shadow-lg hover:shadow-primary-700/25 active:scale-95'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="w-4 h-4" />
                Đã thêm
              </>
            ) : (
              <>
                <ShoppingBag className="w-4 h-4" />
                Thêm vào giỏ
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ProductCatalog() {
  return (
    <section id="products" className="py-20 lg:py-28 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-14 max-w-2xl mx-auto">
          <span className="inline-block px-4 py-1.5 bg-primary-100 text-primary-700 text-sm font-semibold rounded-full mb-4">
            Sản phẩm
          </span>
          <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-gray-900 mb-4">
            4 Quy Cách Sản Phẩm AN MÌ
          </h2>
          <p className="text-gray-600 leading-[150%]">
            Từ gói tiết kiệm dùng tại nhà đến thùng tiêu chuẩn cho căng tin & văn phòng – chọn quy cách phù hợp với nhu cầu của bạn.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
