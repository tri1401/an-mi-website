import { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, Award, Leaf } from 'lucide-react';
import { useCart } from '@/context/CartContext';

const navLinks = [
  { label: 'Trang chủ', href: '#hero' },
  { label: 'Sản phẩm', href: '#products' },
  { label: 'Dinh dưỡng', href: '#nutrition' },
  { label: 'Câu chuyện', href: '#story' },
  { label: 'Bảng giá', href: '#pricing' },
];

export default function Header() {
  const { totalItems, openCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-lg shadow-primary-900/5'
          : 'bg-white/80 backdrop-blur-sm'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <a href="#hero" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary-600 to-primary-800 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-extrabold text-primary-800 text-base sm:text-lg leading-tight">
                AN MÌ
              </span>
              <span className="text-xs text-gray-500 leading-tight hidden sm:block">
                Mì Xơ Mít Bình Mỹ
              </span>
            </div>
            <div className="hidden lg:flex items-center gap-1.5 ml-2 px-2.5 py-1 bg-accent-50 border border-accent-200 rounded-full">
              <Award className="w-3.5 h-3.5 text-accent-500" />
              <span className="text-xs font-semibold text-accent-700">OCOP 3★</span>
            </div>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <a
                key={link.href}
                href={link.href}
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-primary-700 hover:bg-primary-50 rounded-lg transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Cart & Mobile Menu */}
          <div className="flex items-center gap-2">
            <button
              onClick={openCart}
              className="relative p-2.5 rounded-xl bg-primary-50 hover:bg-primary-100 transition-colors group"
              aria-label="Giỏ hàng"
            >
              <ShoppingBag className="w-5 h-5 text-primary-700 group-hover:scale-110 transition-transform" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 bg-accent-500 text-white text-xs font-bold rounded-full flex items-center justify-center animate-bounce-subtle">
                  {totalItems}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden p-2.5 rounded-xl hover:bg-gray-100 transition-colors"
              aria-label="Menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-1 animate-slide-up">
            {navLinks.map(link => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-primary-700 hover:bg-primary-50 rounded-lg transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
