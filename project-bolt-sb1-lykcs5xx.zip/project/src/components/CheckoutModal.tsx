import { useState } from 'react';
import { X, Check, ShoppingBag, QrCode, Truck, Phone, MapPin, User } from 'lucide-react';
import { useCart, formatVND } from '@/context/CartContext';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FormData {
  fullName: string;
  phone: string;
  address: string;
  deliveryType: 'delivery' | 'pickup';
  paymentMethod: 'cod' | 'transfer';
}

const initialForm: FormData = {
  fullName: '',
  phone: '',
  address: '',
  deliveryType: 'delivery',
  paymentMethod: 'cod',
};

export default function CheckoutModal({ isOpen, onClose }: CheckoutModalProps) {
  const { items, subtotal, shippingFee, total, clearCart } = useCart();
  const [form, setForm] = useState<FormData>(initialForm);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [submitted, setSubmitted] = useState(false);
  const [orderNumber] = useState(() => 'ANM' + Date.now().toString().slice(-6));

  if (!isOpen) return null;

  const validate = (): boolean => {
    const e: Partial<Record<keyof FormData, string>> = {};
    if (!form.fullName.trim()) e.fullName = 'Vui lòng nhập họ và tên';
    if (!form.phone.trim()) e.phone = 'Vui lòng nhập số điện thoại';
    else if (!/^[0-9]{9,11}$/.test(form.phone.trim())) e.phone = 'Số điện thoại không hợp lệ';
    if (form.deliveryType === 'delivery' && !form.address.trim()) e.address = 'Vui lòng nhập địa chỉ giao hàng';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) {
      setSubmitted(true);
    }
  };

  const handleClose = () => {
    if (submitted) {
      clearCart();
      setForm(initialForm);
      setSubmitted(false);
      setErrors({});
    }
    onClose();
  };

  const update = (field: keyof FormData, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: undefined }));
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[60] animate-fade-in" onClick={handleClose} />
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 pointer-events-none">
        <div
          className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto pointer-events-auto animate-scale-in"
          onClick={e => e.stopPropagation()}
        >
          {submitted ? (
            /* Success screen */
            <div className="p-8 text-center">
              <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center mx-auto mb-6 animate-bounce-subtle">
                <Check className="w-10 h-10 text-primary-600" />
              </div>
              <h3 className="font-display font-extrabold text-2xl text-gray-900 mb-2">Đặt hàng thành công!</h3>
              <p className="text-gray-500 mb-6">
                Cảm ơn bạn đã đặt hàng. Chúng tôi sẽ liên hệ xác nhận trong thời gian sớm nhất.
              </p>
              <div className="bg-gray-50 rounded-xl p-5 text-left space-y-2 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Mã đơn hàng</span>
                  <span className="font-bold text-gray-900">{orderNumber}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Người nhận</span>
                  <span className="font-semibold text-gray-900">{form.fullName}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Số điện thoại</span>
                  <span className="font-semibold text-gray-900">{form.phone}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Giao hàng</span>
                  <span className="font-semibold text-gray-900 text-right max-w-[60%]">
                    {form.deliveryType === 'pickup' ? 'Nhận tại Căng tin Trường' : form.address}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Thanh toán</span>
                  <span className="font-semibold text-gray-900">
                    {form.paymentMethod === 'cod' ? 'COD' : 'Chuyển khoản VPBank'}
                  </span>
                </div>
                <div className="flex justify-between text-sm pt-2 border-t border-gray-200">
                  <span className="text-gray-500">Tổng thanh toán</span>
                  <span className="font-display font-extrabold text-lg text-primary-700">{formatVND(total)}</span>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="w-full px-5 py-3.5 bg-primary-700 text-white font-semibold rounded-xl hover:bg-primary-800 transition-colors"
              >
                Hoàn tất
              </button>
            </div>
          ) : (
            /* Checkout form */
            <>
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-2xl">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-primary-700" />
                  <h3 className="font-display font-bold text-lg text-gray-900">Đặt Hàng Trực Tiếp</h3>
                </div>
                <button onClick={handleClose} className="p-2 rounded-lg hover:bg-gray-100 transition-colors">
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="p-6 space-y-5">
                {/* Order summary */}
                <div className="bg-primary-50 rounded-xl p-4 space-y-1.5">
                  {items.map(item => (
                    <div key={item.product.id} className="flex justify-between text-sm">
                      <span className="text-gray-600">
                        {item.product.shortName} <span className="text-gray-400">×{item.quantity}</span>
                      </span>
                      <span className="font-semibold text-gray-900">{formatVND(item.product.price * item.quantity)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between text-sm pt-2 border-t border-primary-200">
                    <span className="text-gray-600">Phí vận chuyển</span>
                    <span className="font-semibold text-gray-900">
                      {shippingFee === 0 ? 'Miễn phí' : formatVND(shippingFee)}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="font-bold text-gray-900">Tổng cộng</span>
                    <span className="font-display font-extrabold text-lg text-primary-700">{formatVND(total)}</span>
                  </div>
                </div>

                {/* Form fields */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Họ và tên</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      value={form.fullName}
                      onChange={e => update('fullName', e.target.value)}
                      className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl text-sm focus:outline-none transition-colors ${
                        errors.fullName ? 'border-red-300' : 'border-gray-200 focus:border-primary-400'
                      }`}
                      placeholder="Nguyễn Văn A"
                    />
                  </div>
                  {errors.fullName && <p className="text-xs text-red-500 mt-1">{errors.fullName}</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">Số điện thoại</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={e => update('phone', e.target.value)}
                      className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl text-sm focus:outline-none transition-colors ${
                        errors.phone ? 'border-red-300' : 'border-gray-200 focus:border-primary-400'
                      }`}
                      placeholder="0912345678"
                    />
                  </div>
                  {errors.phone && <p className="text-xs text-red-500 mt-1">{errors.phone}</p>}
                </div>

                {/* Delivery type */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Phương thức nhận hàng</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => update('deliveryType', 'delivery')}
                      className={`flex items-center gap-2 px-4 py-3 border-2 rounded-xl text-sm font-medium transition-colors ${
                        form.deliveryType === 'delivery'
                          ? 'border-primary-500 bg-primary-50 text-primary-700'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      <Truck className="w-4 h-4" />
                      Giao tận nơi
                    </button>
                    <button
                      onClick={() => update('deliveryType', 'pickup')}
                      className={`flex items-center gap-2 px-4 py-3 border-2 rounded-xl text-sm font-medium transition-colors ${
                        form.deliveryType === 'pickup'
                          ? 'border-primary-500 bg-primary-50 text-primary-700'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      <MapPin className="w-4 h-4" />
                      Căng tin Trường
                    </button>
                  </div>
                </div>

                {form.deliveryType === 'delivery' && (
                  <div className="animate-slide-up">
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5">Địa chỉ giao hàng</label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3.5 w-4 h-4 text-gray-400" />
                      <textarea
                        value={form.address}
                        onChange={e => update('address', e.target.value)}
                        rows={2}
                        className={`w-full pl-10 pr-4 py-3 border-2 rounded-xl text-sm focus:outline-none transition-colors resize-none ${
                          errors.address ? 'border-red-300' : 'border-gray-200 focus:border-primary-400'
                        }`}
                        placeholder="Số nhà, đường, phường, quận, TP."
                      />
                    </div>
                    {errors.address && <p className="text-xs text-red-500 mt-1">{errors.address}</p>}
                  </div>
                )}

                {/* Payment method */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Phương thức thanh toán</label>
                  <div className="space-y-2">
                    <button
                      onClick={() => update('paymentMethod', 'cod')}
                      className={`w-full flex items-center gap-3 px-4 py-3 border-2 rounded-xl text-sm font-medium transition-colors text-left ${
                        form.paymentMethod === 'cod'
                          ? 'border-primary-500 bg-primary-50 text-primary-700'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      <Truck className="w-5 h-5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="font-semibold">Thanh toán khi nhận hàng (COD)</div>
                        <div className="text-xs text-gray-400">Thanh toán bằng tiền mặt khi nhận sản phẩm</div>
                      </div>
                    </button>
                    <button
                      onClick={() => update('paymentMethod', 'transfer')}
                      className={`w-full flex items-center gap-3 px-4 py-3 border-2 rounded-xl text-sm font-medium transition-colors text-left ${
                        form.paymentMethod === 'transfer'
                          ? 'border-primary-500 bg-primary-50 text-primary-700'
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      <QrCode className="w-5 h-5 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="font-semibold">Chuyển khoản QR Ngân hàng (VPBank)</div>
                        <div className="text-xs text-gray-400">Quét mã QR và chuyển khoản trước khi nhận hàng</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Submit */}
                <button
                  onClick={handleSubmit}
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 bg-primary-700 text-white font-semibold rounded-xl hover:bg-primary-800 hover:shadow-lg hover:shadow-primary-700/25 active:scale-95 transition-all"
                >
                  Đặt hàng – {formatVND(total)}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
