import anMiProductImage from '@/assets/an-mi-product.svg';

export interface Product {
  id: string;
  name: string;
  shortName: string;
  description: string;
  price: number;
  originalPrice?: number;
  unit: string;
  weight: string;
  badge: string;
  image: string;
  features: string[];
  isBundle?: boolean;
}

export const products: Product[] = [
  {
    id: 'p1',
    name: 'AN MÌ – Dạng Gói Tiết Kiệm',
    shortName: 'Gói Tiết Kiệm 75g',
    description: 'Gói mì xơ mít sấy lạnh tiện dụng, lý tượng cho bữa ăn tại nhà hàng ngày. Đậm đà hương vị tự nhiên, đầy đủ chất xơ.',
    price: 15000,
    unit: 'gói',
    weight: '75g',
    badge: 'Tiết kiệm – Dùng tại nhà',
    image: anMiProductImage,
    features: ['Sấy lạnh -35°C', '15-20% chất xơ', 'Giảm 35% tinh bột', '0% Trans-fat'],
  },
  {
    id: 'p2',
    name: 'AN MÌ – Dạng Ly Giấy Tiện Lợi',
    shortName: 'Ly Giấy 80g',
    description: 'Ly giấy tiện lợi 3 phút, chỉ cần thêm nước sôi. Hoàn hảo cho văn phòng và sinh viên bận rộn.',
    price: 22000,
    unit: 'ly',
    weight: '80g',
    badge: 'Tiện lợi 3 phút – Văn phòng & Sinh viên',
    image: anMiProductImage,
    features: ['3 phút chế biến', 'Ly giấy thân thiện môi trường', '20% chất xơ', 'Không cần nấu'],
  },
  {
    id: 'p3',
    name: 'Thùng Mì Gói AN MÌ (30 gói x 75g)',
    shortName: 'Thùng 30 Gói',
    description: 'Mua thùng 30 gói tiết kiệm hơn 50.000đ. Lựa chọn tối ưu cho gia đình sử dụng thường xuyên.',
    price: 400000,
    originalPrice: 450000,
    unit: 'thùng',
    weight: '30 x 75g',
    badge: 'Mua thùng tiết kiệm 50k',
    image: anMiProductImage,
    features: ['30 gói x 75g', 'Tiết kiệm 50.000đ', 'Bảo quản 12 tháng', 'Quy cách gia đình'],
    isBundle: true,
  },
  {
    id: 'p4',
    name: 'Thùng Mì Ly AN MÌ (12 ly x 80g)',
    shortName: 'Thùng 12 Ly',
    description: 'Quy cách chuẩn cho căng tin và văn phòng. 12 ly tiện lợi, dễ phân phối và sử dụng tập thể.',
    price: 235000,
    originalPrice: 264000,
    unit: 'thùng',
    weight: '12 x 80g',
    badge: 'Quy cách chuẩn Căng tin & Văn phòng',
    image: anMiProductImage,
    features: ['12 ly x 80g', 'Tiết kiệm 29.000đ', 'Chuẩn căng tin', 'Phân phối dễ dàng'],
    isBundle: true,
  },
];

export interface NutritionRow {
  label: string;
  anMi: string;
  traditional: string;
  shirataki: string;
  highlight?: boolean;
}

export const nutritionRows: NutritionRow[] = [
  { label: 'Chất xơ', anMi: '4.5g / vắt 75g (15-20% xơ mít)', traditional: '~2g', shirataki: '~3g', highlight: true },
  { label: 'Năng lượng (kcal)', anMi: '260 kcal', traditional: '450 kcal', shirataki: '~10 kcal' },
  { label: 'Chất béo (g)', anMi: '1.5g', traditional: '18g', shirataki: '0g' },
  { label: 'Trans-fat', anMi: '0%', traditional: 'Có (chiên dầu)', shirataki: '0%', highlight: true },
  { label: 'Công nghệ chế biến', anMi: 'Sấy lạnh -35°C', traditional: 'Chiên dầu > 150°C', shirataki: 'Kết cấu konjac' },
  { label: 'Giá thành', anMi: '15.000đ – 22.000đ', traditional: '4.500đ – 12.000đ', shirataki: '45.000đ – 80.000đ' }
];

export interface ProcessStep {
  step: number;
  title: string;
  description: string;
  icon: string;
}

export const processSteps: ProcessStep[] = [
  {
    step: 1,
    title: 'Thu gom & Khử chát',
    description: 'Thu gom xơ mít tươi từ Bình Mỹ, xử lý khử nhựa và chát bằng phương pháp tự nhiên không hóa chất.',
    icon: 'sprout',
  },
  {
    step: 2,
    title: 'Nghiền & Phối trộn 20:80',
    description: 'Nghiền xơ mít và phối trộn với bột lúa mì theo tỷ lệ 20:80, tạo nền tảng dinh dưỡng cân bằng.',
    icon: 'blend',
  },
  {
    step: 3,
    title: 'Ép sợi & Hấp',
    description: 'Ép thành sợi mì mịn màng và hấp chín bằng hơi nước, giữ nguyên giá trị dinh dưỡng tự nhiên.',
    icon: 'waves',
  },
  {
    step: 4,
    title: 'Sấy lạnh Freeze-drying -35°C',
    description: 'Sấy lạnh ở -35°C không qua chiên dầu, bảo toàn chất xơ, vitamin và cấu trúc sợi mì hoàn hảo.',
    icon: 'snowflake',
  },
  {
    step: 5,
    title: 'Đóng gói OCOP',
    description: 'Đóng gói theo chuẩn OCOP 3 Sao Bình Mỹ, đảm bảo vệ sinh an toàn thực phẩm và truy xuất nguồn gốc.',
    icon: 'package',
  },
];
